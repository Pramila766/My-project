﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ExportToExcel.Models;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Text;
using System.Data;
using OfficeOpenXml;
using ClosedXML.Excel;
using Microsoft.Extensions.Configuration;

namespace ExportToExcel.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private ReportDataContext _db = new ReportDataContext();
        private readonly ILogger<HomeController> _logger;
        private readonly IConfiguration _configuration;

        public HomeController(ILogger<HomeController> logger, IConfiguration configuration)
        {
            _configuration = configuration;
            _logger = logger;
          
        }
        
        public IActionResult Index()
        {
            var dept = _db.Department.ToList();
            return View(dept);
        }

        public IActionResult ExportToExcel()
        {

            var depts = _db.Department.ToList();

            using (var workbook = new XLWorkbook())
            {
                var worksheet = workbook.Worksheets.Add();
                var currentRow = 1;
                worksheet.Cell(currentRow, 1).Value = "Department Name";
                worksheet.Cell(currentRow, 2).Value = "Quantity";
                foreach (var dept in depts)
                {
                    currentRow++;
                    worksheet.Cell(currentRow, 1).Value = dept.Name;
                    worksheet.Cell(currentRow, 2).Value = dept.Quantity;
                }

                using (var stream = new MemoryStream())
                {
                    workbook.SaveAs(stream);
                    var content = stream.ToArray();

                    return File(content, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","Department.xlsx");

                }
            }

        }
                      

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
